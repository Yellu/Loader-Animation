package in.goindigo.loaderanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    View view1, view2, view3;
    Animation fadeIn1, fadeIn2, fadeIn3, fadeOut1, fadeOut2;

    Button start, stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view1 = findViewById(R.id.view_1);

        view2 = findViewById(R.id.view_2);

        view3 = findViewById(R.id.view_3);

        start = findViewById(R.id.button);

        stop = findViewById(R.id.button2);

        fadeIn1 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in);
        fadeIn2 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in);
        fadeIn3 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in);

        fadeOut1 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_out);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fadeIn1.setStartOffset(100);
                fadeIn2.setStartOffset(200);
                fadeIn3.setStartOffset(300);

                view1.startAnimation(fadeIn1);

                fadeIn1.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        view1.startAnimation(fadeOut1);
                        view2.startAnimation(fadeIn2);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });

                fadeIn2.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        view2.startAnimation(fadeOut1);
                        view3.startAnimation(fadeIn3);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });

                fadeIn3.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
//                        view1.startAnimation(fadeOut1);
//                        view2.startAnimation(fadeOut1);
                        view3.startAnimation(fadeOut1);

                        view1.startAnimation(fadeIn1);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });

            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view1.clearAnimation();
                view2.clearAnimation();
                view3.clearAnimation();
            }
        });

    }


}
